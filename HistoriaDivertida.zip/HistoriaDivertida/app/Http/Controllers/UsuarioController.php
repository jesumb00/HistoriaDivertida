<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UsuarioController extends Controller
{
    public function index() // Display a listing of the resource.
    {
        $usuarios = Usuario::orderBy('name')->get();
        return view('usuarios_index', compact('usuarios'));
    }
    public function exist(){
        $array=request()->only('email','password');

        if(Auth::attempt($array)){
            request()->session()->regenerate();
            return view('home');
        }else{
            return redirect('/loggin');
        }
    }
    public function create() // Show the form for creating a new resource.
    {
        return view('usuarios_create');
    }

    public function store(Request $request) // Store a newly created resource in storage.
    {
        $this->validate($request, [
            'name' => 'required',
            'surname' => 'required',
            'email' => 'required',
            'password' => 'required',
            'type' => 'required',
        ]);

        $usuario = new Usuario();
        $usuario->name = $request->name;
        $usuario->surname = $request->surname;
        $usuario->email = $request->email;
        $usuario->password = $request->password;
        $usuario->type = $request->type;
        $usuario->save();

        return redirect()->route('usuarios.index');
    }

    public function show(Usuario $usuario) // Display the specified resource.
    {
        return view('usuarios_show', compact('usuario'));
    }

    public function edit(Usuario $usuario) // Show the form for editing the specified resource.
    {
        return view('usuarios_edit', compact('usuario'));
    }

    public function update(Request $request, Usuario $usuario) // Update the specified resource in storage.
    {
        $this->validate($request, [
            'name' => 'required',
            'surname' => 'required',
            'email' => 'required',
            'password' => 'required',
            'type' => 'required',
        ]);

        $usuario->name = $request->name;
        $usuario->surname = $request->surname;
        $usuario->email = $request->email;
        $usuario->password = $request->password;
        $usuario->type = $request->type;
        $usuario->save();

        return redirect()->route('usuarios.index');
    }

    public function destroy(Usuario $usuario) // Remove the specified resource from storage.
    {
        $usuario->delete();
        return redirect()->route('usuarios.index');
    }
}
