<!DOCTYPE html>
<html lang="es-ES">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>login</title>
        <link rel="stylesheet" href="<?php echo e(asset('style.loggin.css')); ?>">
    </head>
    <body>
       <section class="login">
           <img src="<?php echo e(asset('img/movimiento/color1.png')); ?>" alt="1" id="image">
           <form class="formulario">
                <input id="input-user" type="text" placeholder="Usuario" autocomplete="off">
                <input id="input-password" type="password" placeholder="************">
                <button type="submit">Login</button>
                <input type="checkbox" id="input-remember" class="checkbox" >
                <span id="remember">Remember me</span>

            </form>
       </section>
       <script src="<?php echo e(asset('javascript.loggin.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /var/www/html/resources/views/loggin/loggin.blade.php ENDPATH**/ ?>
