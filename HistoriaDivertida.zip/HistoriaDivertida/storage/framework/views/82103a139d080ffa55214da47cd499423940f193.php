<header>
    <input type="search" placeholder="Busca tu mito">
    <section id="section-menu">
        <article class="menu">
        <a href="/home"><p>Inicio</p></a>
        </article>

        <article class="menu">
        <a href="/plays"><p>Obras</p></a>
        </article>

        <article class="menu">
        <a href="/myths"><p>Mitos</p></a>
        </article>

        <article class="menu">
        <a href="/games"><p>Juegos</p></a>
        </article>
        <?php if(auth()->guard()->check()): ?>
        <article class="menu">
        <a href="/task"><p>Tareas</p></a>
        </article>
        <?php endif; ?>
    </section>
    <?php if(auth()->guard()->check()): ?>
        <img id="photo_user" src="<?php echo e(asset('/img/user_no_auth.png')); ?>" alt="photo_user">
        <a  id="user" href="/user_profile"><p>mi perfil</p></a>
    <?php else: ?>
        <a href="/loggin">Loggin</a>
    <?php endif; ?>
</header>
<?php /**PATH /var/www/html/resources/views/components/menu.blade.php ENDPATH**/ ?>