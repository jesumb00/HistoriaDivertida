<footer>
    <section>
        <article><a href=""><img class="social-media" src="<?php echo e(asset('img/footer/facebook.png')); ?>">Facebook</a></article>
        <article><a href=""><img class="social-media" src="<?php echo e(asset('img/footer/instagram.png')); ?>">Instagram</a></article>
        <article><a href=""><img class="social-media" src="<?php echo e(asset('img/footer/pinterest.png')); ?>">Pinterest</a></article>
        <article><a href=""><img class="social-media" src="<?php echo e(asset('img/footer/twitter.png')); ?>">Twitter</a></article>
    </section>
</footer>
<?php /**PATH /var/www/html/resources/views/components/footer.blade.php ENDPATH**/ ?>