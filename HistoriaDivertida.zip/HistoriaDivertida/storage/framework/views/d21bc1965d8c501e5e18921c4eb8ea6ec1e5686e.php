<!DOCTYPE html>
<html lang="es-ES">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>login</title>
    <link rel="stylesheet" href="<?php echo e(asset('styles/style.menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('styles/style.welcome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('styles/style.footer.css')); ?>">
</head>
<body>
<?php if (isset($component)) { $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Menu::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Menu::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9)): ?>
<?php $component = $__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9; ?>
<?php unset($__componentOriginald0b4154eafa6ddf1d90e70a636ac005452fbb4c9); ?>
<?php endif; ?>
<main>
        <section id="presentation">
            <h1 >Historia divertida</h1>
            <sub>Aqui la historia no te aburrira</sub>
        </section>
        <section id="function-descripcion">
            <p class="function-description">Pulsa el boton de la parte del sitio web quiere acceder.</p>
            <p class="function-description">Puedes ver una pequeña parte del museo,comprar ,organizar tu visita o saber mas de nosotros</p>
        </section>
        <section id="visual-nav">
            <article>

            </article>
            <article>

            </article>
            <article>

            </article>
            <article>

            </article>
        </section>
        <section id="website-description">
            <article id="title-one">
                <h1 class="title">Expande tus conocimientos</h1>
            </article>
            <article id="explanation">
                <p class="description">Aprende las maravillas de las antiguas civilizaciones visitándonos en nuestro museo laguna donde nos dedicaremos a descubrir las maravillas de la Antigua Grecia.</p>
                <p class="description">En el museo encontraras estatuas y monumentos de distintas épocas de Grecia desde el inicio, hasta el final.</p>
            </article>
        </section>
        <section class="previous">
            <h1 class="title">¿Como se creo el universo griego?</h1>
            <iframe src="https://www.youtube.com/embed/6T8m5t5VkZc" frameborder="0" allow="accelerometer; gyroscope" ></iframe>
        </section>
        <section class="previous">
            <h1 class="title">¿Y el egipcio?</h1>
            <iframe src="https://www.youtube.com/embed/bOK8EdWl1vM"  frameborder="0" allow="accelerometer; gyroscope"></iframe>
        </section>
</main>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>
