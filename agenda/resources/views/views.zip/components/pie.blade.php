<footer>
    <h3>Estas en {{$lugar}}</h3><p>IES LAGUNA DE JOAZTEL</p><p>Fecha/Hora:-->{{$fecha}}</p>
</footer>
