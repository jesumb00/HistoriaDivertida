<header>
    <H2><a href='/'>Agenda</a></H2>
    <nav><a class='menu' href='/'>Inicio</a><a class='menu' href='/categorias'>Categorias</a><a class='menu' href=''>Personas</a></nav>
</header>
