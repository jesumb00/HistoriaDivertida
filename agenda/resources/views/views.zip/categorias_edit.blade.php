<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <link rel="stylesheet" href="{{asset('style.css')}}">
</head>
<body>
<x-menu />
<h2>Actualizar categoria</h2>
<form action='{{route('categorias.update',$persona)}}' method='post'>
    <input type='text' name='nombre' value='{{$categoria->nombre}}'>
    <input type='hidden' name='nombreAntiguo' value='{{$categoria->nombre}}'>
    <input type='submit' name='actualizar' value='Actualizar'>
    <input type='submit' name='eliminar' value='Eliminar'>
</form>
<x-pie lugar="editar" fecha="{{Carbon\Carbon::now()->toDateTimeString()}}"/>
</body>
</html>
